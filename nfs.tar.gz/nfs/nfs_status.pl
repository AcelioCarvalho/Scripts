#!/usr/bin/perl

# Routine to check status if NFS server is down to unmout NFS client partition without use autoFs
# Implemented routine to solve SUS BUG: 27317

use DBI;
require "/opt/omne/lib/lib-apply/lib-database.pl";

my $DEBUG = 0;

# Get client NFS configs from database: IP nfs server, port used from NFS and montpoint from directory addr  

my %dbconf = db::baseconf();
my $dbh = db::connect("brcconfig", 1);
my $sql = "select storage_nfs_addr, storage_nfs_id, storage_nfs_extra, storage_nfs_dir, host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from storage_nfs left join obj_addr on obj_addr.id = storage_nfs.storage_nfs_addr where box_id = '".$dbconf{ BOX_ID }."'";
my $sth = db::select($dbh,$sql);

# For each nfs server configured, check his status to unmout if server is down.
while(my $conf_nfs = $sth->fetchrow_hashref){
        
	my $nfs_server = "$conf_nfs->{host}";
	if ($DEBUG) {
		print ("> Nfs Server IP: $nfs_server\n");
	}
	
	my $mount_point = "$conf_nfs->{host}:$conf_nfs->{storage_nfs_dir}"; 
	if ($DEBUG) {
		print ("> Mount Point: $mount_point\n");
	}
	
	my $regex_port=$conf_nfs->{storage_nfs_extra};
	my $nfs_id = $conf_nfs->{storage_nfs_id};
	if  ($DEBUG) {
		print ("> Id: $nfs_id\n");
	}

	my $port = 2049; 
	if ($regex_port =~ /port=(\d+)/) {
		$port = $1;
	}
     
	if ($DEBUG) {
		print("> Port: $port\n");
	}

	if($nfs_server and $port){
		$result = `echo exit | timeout --signal=9 2 telnet $nfs_server $port 2>&1`;
		if ($result =~ /Connected/) {		
	  		if ($DEBUG) {
				 print("> Server ON\n");
			}
	        `echo exit | df -h /storage/nfs/$nfs_id`;
 		}
		else {
			system("umount -fl $mount_point");
        	if ($DEBUG) {
					print("> Server Off\n");
			}
		}

		if ($DEBUG) {
			print ("Result from telnet: $result\n");
		}
	}		
}

$sth->finish;
