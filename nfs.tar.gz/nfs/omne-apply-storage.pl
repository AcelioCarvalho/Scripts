#!/usr/bin/perl
# teste_gitzsefv
our $progname = $0;
$progname =~ s/^.*(\/)//g;

use DBI;
use Getopt::Long;

require "/opt/omne/lib/lib-apply/lib-debug.pl";
require "/opt/omne/lib/lib-apply/lib-database.pl";

# --- Arguments -------------------------------------------------------------- #
my $help = 0;

GetOptions(
	'help'    => \$help,
	'debug'   => \$debug,
) or HelpMessage();

HelpMessage() if $help;

sub HelpMessage
{
	print STDERR "Usage: $progname [OPTIONS]\n";
	print STDERR "Script to mount/umount storages.\n";
	print STDERR "\n";
	print STDERR "Optional Arguments\n";
	print STDERR "  -d, --debug    Switch on|off debug mode\n";
	print STDERR "  -h, --help     Display this help message and exit\n";
	print STDERR "\n";
	print STDERR "Copyright BLOCKBIT® (http://www.blockbit.com/)\n";
	print STDERR "All rights reserved <info\@blockbit.com>\n\n";

	exit 0;
}

# --- Script Code ------------------------------------------------------------ #

DebugMessage("running");

my %dbconf = db::baseconf();

my $dbh = db::connect("brcconfig", 1);

#-- Global ------------------------------------------#
DebugMessage(">/etc/auto.master.d/storage-nfs.autofs");
open(FILE,'>','/etc/auto.master.d/storage-nfs.autofs');
print FILE "/storage/nfs    /etc/auto.master.d/auto-nfs.misc --timeout=10\n";
close(FILE);

DebugMessage(">/etc/auto.master.d/storage-smb.autofs");
open(FILE,'>','/etc/auto.master.d/storage-smb.autofs');
print FILE "/storage/smb    /etc/auto.master.d/auto-smb.cifs-shares --timeout=10\n";
close(FILE);

DebugMessage(">/etc/auto.master.d/storage-usb.autofs");
open(FILE,'>','/etc/auto.master.d/storage-usb.autofs');
print FILE "/storage/usb    /etc/auto.master.d/auto-ext.vol --timeout=10\n";
close(FILE);

DebugMessage(">/etc/auto.master.d/auto-nfs.misc");
open(FILE_NFS,'>','/etc/auto.master.d/auto-nfs.misc');
my $sql = "select *, host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from storage_nfs left join obj_addr on obj_addr.id = storage_nfs.storage_nfs_addr where box_id = '".$dbconf{ BOX_ID }."'";
my $sth = db::select($dbh,$sql);
my $nfs_configured = 0;

while(my $conf_nfs = $sth->fetchrow_hashref){
	print FILE_NFS "$conf_nfs->{storage_nfs_id} -rw,$conf_nfs->{storage_nfs_extra} $conf_nfs->{host}:$conf_nfs->{storage_nfs_dir}"."\n";
	$nfs_configured = ($conf_nfs->{storage_nfs_id} != null || $conf_nfs->{storage_nfs_id} != "" ) ? '1' : '0';

}
close(FILE_NFS);
$sth->finish;

if ($nfs_configured) {
		#Adding routine to check nfs server status to unmount when server is off in cron 
		DebugMessage(">Add nfs_status routine on cron");
        open(NFS_STATUS, ">/etc/cron.d/nfs_status");
        print NFS_STATUS "SHELL=/bin/bash\n";
        print NFS_STATUS "PATH=/sbin:/bin:/usr/sbin:/usr/bin\n";
        print NFS_STATUS "MAILTO=root\n\n";
        print NFS_STATUS "* * * * * root perl /opt/omne/bin/nfs_status.pl &>/dev/null\n";
        DebugMessage("reload crond");
        system("/usr/bin/systemctl restart crond >>/dev/null 2>&1");
		close(NFS_STATUS);
		
		#BUG-27317: NFS storage causes SNMPD service unavailability
        my $found = "";
        $found = system("grep -xq '^skipNFSInHostResources .*' /etc/snmp/snmpd.conf");
        if ($found != "0") {
			DebugMessage(">Add skip NFS param on snmpd service");
			# Add config to bypass mount NFS in Snmpd Service
			system (q(`sed -i '$s/$/\n \nskipNFSInHostResources true/' /etc/snmp/snmpd.conf`));
        }
}

DebugMessage(">/etc/auto.master.d/auto-smb.cifs-shares");
open(FILE_SMB,'>','/etc/auto.master.d/auto-smb.cifs-shares');
my $sql = "select *, (select decrypt(storage_smb_pass::bytea, decode(digital_sign, 'hex'), crypt_pass)::text as smb_pass), host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from storage_smb left join obj_addr on obj_addr.id = storage_smb.storage_smb_addr left join security on security.crypt_pass is not null";
my %DB=('full_query' => $sql);
my $sth = db::select($dbh,$sql);
while(my $conf_smb = $sth->fetchrow_hashref){
	open(CREDENTIALS,'>','/etc/auto.master.d/.smbcredentials'.$conf_smb->{storage_smb_id});
	print CREDENTIALS "username=$conf_smb->{storage_smb_user}\n";
	print CREDENTIALS "password=$conf_smb->{smb_pass}\n";
	close(CREDENTIALS);

	print FILE_SMB "$conf_smb->{storage_smb_id} -fstype=cifs,rw,credentials=/etc/auto.master.d/.smbcredentials$conf_smb->{storage_smb_id},file_mode=0777,dir_mode=0777 ://$conf_smb->{host}/$conf_smb->{storage_smb_dir}"."\n";
}
$sth->finish;
close(FILE_SMB);

&insertUsb();

DebugMessage(">/etc/auto.master.d/auto-ext.vol");
open(FILE_USB,'>','/etc/auto.master.d/auto-ext.vol');
my $sql ="select storage_usb_id, storage_usb_desc, storage_usb_dev, box_id from storage_usb order by storage_usb_desc";
my $sth = db::select($dbh,$sql);
while(my $conf_usb = $sth->fetchrow_hashref){
	print FILE_USB "$conf_usb->{storage_usb_id} -fstype=auto	:$conf_usb->{storage_usb_dev}"."\n";
}
$sth->finish;
close(FILE_USB);

$dbh->disconnect;
DebugMessage("reload autofs");
system('systemctl restart autofs');
DebugMessage("finish");

sub insertUsb(){
    my %usbInterfaces = &getUsbInterfaces();

    my %devices = ();
	my $sql ="select storage_usb_id, storage_usb_desc, storage_usb_dev, box_id from storage_usb order by storage_usb_desc";
	my $sth = db::select($dbh,$sql);
	while(my $conf_usb = $sth->fetchrow_hashref){
        my $storage_usb_id   = $conf_usb->{storage_usb_id};
        my $storage_usb_dev  = $conf_usb->{storage_usb_dev};
        my $storage_usb_desc = $conf_usb->{storage_usb_desc};
        my $box_id           = $conf_usb->{box_id};
        $devices{"$box_id.$storage_usb_dev"} = 0;
    }

    foreach my $dev (keys %usbInterfaces)
	{
		my $desc = $usbInterfaces{ $dev };

		if (exists $devices{ "$dbconf{ BOX_ID }.$dev" })
		{
			$devices{ "$dbconf{ BOX_ID }.$dev" } = 1;
			next;
		}
		DebugMessage("add device: $dev");
		$dbh->do("insert into storage_usb (storage_usb_desc, storage_usb_dev, box_id) values('$desc','$dev','$dbconf{ BOX_ID }')");
    }

	foreach my $dev (keys %devices)
	{
		my $found = $devices{ $dev };
		next if $found;

		my $dev = (split(/\./, $dev))[1];

		DebugMessage("del device: $dev");
		$dbh->do("delete from storage_usb where box_id = $dbconf{ BOX_ID } and storage_usb_dev = '$dev'");
	}
}

sub getUsbInterfaces()
{
	my @devices = `/usr/sbin/fdisk -l |grep Disk |grep "/dev" |grep -v mapper`;

    my %usbInterfaces = ();

    foreach my $line (@devices)
	{
		chomp $line;

		my $dev = (split(/\s+/, $line))[1];
		$dev =~ s/\://g;

		my $model = `/usr/sbin/parted $dev print free |grep Model`;
		chomp $model;
		$model =~ s/^.*\: //;

		my @parts = `/usr/sbin/parted $dev print free |grep ext4`;
		foreach my $p (@parts)
		{
			chomp $p;
			my @data = split(/\s+/, $p);
			next if scalar @data > 7;
			my $number = $data[1];
			$dev .= $number;
			$model .= " - #$number";

			my $mount = `/usr/bin/mount -l | grep $dev`;
			next if $mount;

			$usbInterfaces{ $dev } = $model;
		}
    }

    return %usbInterfaces;
}
