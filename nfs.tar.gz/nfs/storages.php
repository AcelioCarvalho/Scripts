<?php

if (!isset($_SESSION['REMOTE_USER'])) {
    session_start();
}

require_once('/opt/omne/admin/i18n.php');
session_write_close();

require_once("/opt/omne/admin/lib/lib-apply/lib-apply.php");
include_once '/opt/omne/admin/lib/lib-database.php';
include_once '/opt/omne/admin/lib/lib-acl.php';
include_once '/opt/omne/admin/lib/lib-session.php';
include_once '/opt/omne/admin/lib/lib-common.php';

chkSessionAjax(); //RETORNA MSG DE ERRO

if ($_REQUEST['act'] == 'delObject') {
    aclAjax("system", "MANAGER", "edit"); //RETORNA MSG DE ERRO

    delObject();
    return;
} else if ($_REQUEST['act'] == 'getObject') {
    aclAjax("system", "MANAGER", "view"); //RETORNA MSG DE ERRO

    getObject();
    return;
} else if ($_REQUEST['act'] == 'saveObject') {
    aclAjax("system", "MANAGER", "edit"); //RETORNA MSG DE ERRO

    saveObject();
    return;
} else if ($_REQUEST['act'] == 'getObjectSmb') {
    aclAjax("system", "MANAGER", "view"); //RETORNA MSG DE ERRO

    getObjSmb();
    return;
} else if ($_REQUEST['act'] == 'getObjectNfs') {
    aclAjax("system", "MANAGER", "view"); //RETORNA MSG DE ERRO

    getObjNfs();
    return;
} else if ($_REQUEST['act'] == 'getServer') {
    aclAjax("system", "MANAGER", "view"); //RETORNA MSG DE ERRO

    getServer();
    return;
} else if ($_REQUEST['act'] == 'quotastorage') {
    aclAjax("system", "MANAGER", "view"); //RETORNA MSG DE ERRO

    quotastorage();
    return;
} else if ($_REQUEST['act'] == 'reloadUsb') {
    aclAjax("system", "MANAGER", "edit"); //RETORNA MSG DE ERRO

    reloadUsb();
    return;
} else if ($_REQUEST['act'] == 'saveSSH') {
    aclAjax("system", "MANAGER", "edit"); //RETORNA MSG DE ERRO

    saveSSH();
    return;
} else if ($_REQUEST['act'] == 'getStorageSSH') {
    aclAjax("system", "MANAGER", "view");

    getStorageSSH();
    return;
}

function validType($str)
{
    if (
        $str == 'storage_smb' ||
        $str == 'storage_nfs' ||
        $str == 'storage_ssh' ||
        $str == 'smb' ||
        $str == 'nfs' ||
        $str == 'ssh' ||
        $str == 'all' ||
        $str == 'storage_usb' ||
        $str == 'disco'
    ) {
        return true;
    } else {
        return false;
    }
}

//GET
function getServer()
{
    $dbh = connectDB();
    $sql = "SELECT
                box_id, description
            FROM box 
            ORDER BY box_id";
    $sth = $dbh->prepare($sql);
    $sth->execute();
    echo json_encode($sth->fetchAll(PDO::FETCH_ASSOC));
    $dbh = null;
}

function getObject()
{


    $page = validFormRequest($ret, "int", 'page', 1);
    $total = validFormRequest($ret, "int", 'total', 1);
    $limit = validFormRequest($ret, "int", 'limit', 1);
    $filter = validFormRequest($ret, "char", 'find', 1);

    if (sizeof($ret) > 0) {
        return array();
        exit;
    }
    $_REQUEST['box_id'] = 1;
    if ($_REQUEST['box_id']) {
        $where = "where  box_id = '" . $_REQUEST['box_id'] . "'";
    }

    $sql = "SELECT 
                storage_smb_id as id, 
                storage_smb_desc as name, 
                storage_smb_dir as dir, 
                'smb' as type 
            FROM 
                storage_smb $where
                AND storage_smb_desc ilike '%$filter%'
            UNION ALL 
            SELECT 
                storage_nfs_id as id, 
                storage_nfs_desc as name, 
                storage_nfs_dir as dir, 
                'nfs' as type 
            FROM 
                storage_nfs $where
                AND storage_nfs_desc ilike '%$filter%'
            UNION ALL 
            SELECT 
                storage_usb_id as id, 
                storage_usb_desc as name, 
                storage_usb_dev as dir, 
                'usb' as type 
            FROM
                storage_usb $where 
              AND storage_usb_desc ilike '%$filter%'

            UNION ALL 
            SELECT 
                storage_ssh_id as id, 
                storage_ssh_desc as name, 
                storage_ssh_dir as dir, 
                'ssh' as type 
            FROM 
                storage_ssh
                WHERE storage_ssh_desc ilike '%$filter%' ";

    $sql .= "order by type, name ";

    $sqlTot = $sql;
    if (!isset($offset))
        $offset = 0;

    if (isset($page))
        $offset = ($page * $limit) - $limit;

    if ($limit) {
        $sql .= " limit $limit";
    }

    if ($offset) {
        $sql .= " offset $offset";
    }

    $dbh = connectDB();
    $sth = $dbh->prepare($sql);
    $sth->execute();

    $sqlTotal = "select count(*) from ($sqlTot) as tot";
    $sthTotal = $dbh->prepare($sqlTotal);
    $sthTotal->execute();


    $array['page'] =  $page;
    $array['obj'] = $sth->fetchAll(PDO::FETCH_ASSOC);
    $array['total'] = $sthTotal->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($array);
}

function getObjSmb()
{
    $sql = "SELECT
                storage_smb_id as id,
                storage_smb_addr,
                storage_smb_desc as name,
                obj_addr.data->>'obj_addr-name' as addr_name,
                obj_addr.data->>'obj_addr-description' as addr_description,
                storage_smb_user,
                storage_smb_pass,
                storage_smb_dir
            FROM storage_smb
            LEFT JOIN obj_addr on obj_addr.id = storage_smb_addr ";

    if ($_REQUEST['id']) {
        $sql .= " where storage_smb_id = '" . $_REQUEST['id'] . "'";
    }

    $sql .= " order by storage_smb_desc limit 300 ";
    $dbh = connectDB();
    $sth = $dbh->prepare($sql);
    $sth->execute();
    echo json_encode($sth->fetchAll(PDO::FETCH_ASSOC));
}

function getObjNfs()
{
    $sql = "SELECT
                storage_nfs_id as id,
                storage_nfs_addr,
                storage_nfs_desc as name,
                storage_nfs_extra,
                obj_addr.data->>'obj_addr-name' as addr_name,
                obj_addr.data->>'obj_addr-description' as addr_description,
                storage_nfs_dir
            FROM storage_nfs
            LEFT JOIN obj_addr on obj_addr.id = storage_nfs_addr";

    if ($_REQUEST['id']) {
        $sql .= " where storage_nfs_id = '" . $_REQUEST['id'] . "'";
    }

    $sql .= " order by storage_nfs_desc limit 300 ";
    $dbh = connectDB();
    $sth = $dbh->prepare($sql);
    $sth->execute();
    echo json_encode($sth->fetchAll(PDO::FETCH_ASSOC));
}

//DEL
function delObject()
{
    $type = $_REQUEST['type'];
    $ids = json_decode($_REQUEST['ids']);
    $names = json_decode($_REQUEST['names']);

    if (!validType($_REQUEST['type'])) {
        echo " --";
        return;
    }

    foreach ($ids as $id) {
        if (validForm('int', $id) == 1) {
            if ($type == 'nfs') {
                delObjNfs($id);
            } else if ($type == 'smb') {
                delObjSmb($id);
            } else if ($type == 'disco') {
                delObjUsb($id);
            } else if ($type == 'ssh') {
                delObjSSH($id);
            } else if ($type == 'all') {
                delObjNfs($id);
                delObjSmb($id);
                delObjUsb($id);
                delObjSSH($id);
            }
        }
    }

    $audit = [];
    $audit[] = _("Armazenamento(s) removido(s)");
    $audit[] = _("Armazenamento(s):") . implode("^", $names);
    logAudit("system", "edit", $audit);

    $apply = new LibApply("storage", __FUNCTION__);
    $apply->exec();

    echo 1;
}

function delObjNfs($id)
{
    $dbh = connectDB();

    if (selectOne("SELECT 1 FROM box_backup WHERE backup_type = 'nfs' AND backup_nfs = '$id'", $dbh)) {
        echo _("Objeto em uso no backup do sistema");
        exit;
    }

    $dbh->query("DELETE FROM storage_nfs where storage_nfs_id = '" . $id . "'");
}

function delObjSmb($id)
{
    $dbh = connectDB();
    $dbh->query("DELETE FROM storage_smb where storage_smb_id = '" . $id . "'");
}

function delObjUsb($id)
{
    $dbh = connectDB();

    if (selectOne("SELECT 1 from box_backup where backup_type = 'usb' and backup_usb = '$id'", $dbh)) {
        echo _("Objeto em uso no backup do sistema");
        exit;
    }

    $dbh->query("DELETE FROM storage_usb where storage_usb_id = '" . $id . "'");
    $dbh = null;
}

function delObjSSH($id)
{
    $dbh = connectDB();

    if (selectOne("SELECT 1 from box_backup where backup_type = 'ssh' and backup_ssh = '$id'", $dbh)) {
        echo _("Objeto em uso no backup do sistema");
        exit;
    }

    $dbh->query("DELETE FROM storage_ssh where storage_ssh_id = '" . $id . "'");

    $apply = new LibApply("storages", "delObjSSH");
    $apply->exec();
}

//SAVE
function saveObject()
{
    $_REQUEST['box_id'] = 1;
    $type = $_REQUEST['type'];

    if (!filter_var($_REQUEST['type'], FILTER_CALLBACK, array("options" => "validType"))) {
        echo "";
        return;
    }

    if ($type == 'storage_smb' && !saveObjSmb()) {
        echo "";
        return;
    } else if ($type == 'storage_nfs' && !saveObjNfs()) {
        echo "";
        return;
    }

    echo "1";
    return;
}

function saveObjSmb()
{
    $storage_smb_id = validFormRequest($ret, 'int', 'smb-id', 1);
    $storage_smb_desc = validFormRequest($ret, 'char', 'smb-name');
    // $storage_smb_ip = validFormRequest($ret, 'ipmask', 'smb-src');
    $storage_smb_addr = validFormRequest($ret, 'int', 'smb-src', 1);
    // $storage_smb_addr_modal = validFormRequest($ret, 'int', 'smb-src-complete-modal', 1);
    $storage_smb_user = validFormRequest($ret, 'char', 'smb-login', 1);
    $storage_smb_pass = validFormRequest($ret, 'anychar', 'smb-pass', 1);
    $storage_smb_dir = validFormRequest($ret, 'char', 'smb-dir', 1);
    $box_id = 1;


    // Retorna o campo com erro
    if (sizeof($ret) > 0) {
        echo json_encode($ret, JSON_UNESCAPED_UNICODE);
        exit;
    }

    $audit = array();

    $dbh = connectDB();
    if ($storage_smb_id) {
        array_push($audit, _("Alterado armazenamento SMB:"));
        if ($_REQUEST['smb-pass'] != '***********') {
            $storage_smb_pass = "(SELECT encrypt('" . $storage_smb_pass . "'::bytea, decode(digital_sign, 'hex'), crypt_pass) as teste from security) ";
            $pass = ',storage_smb_pass =' . $storage_smb_pass;
        }

        $sql = "UPDATE storage_smb SET storage_smb_desc = '$storage_smb_desc', storage_smb_addr = '$storage_smb_addr', storage_smb_user = '$storage_smb_user' $pass, storage_smb_dir = '$storage_smb_dir' where storage_smb_id = '" . $storage_smb_id . "'";
        $dbh->query($sql);
        $storage_smb_name = selectOne("SELECT host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from obj_addr where id = $storage_smb_addr ", $dbh);
    } else {
        $sql = "SELECT 1 FROM storage_smb WHERE storage_smb_desc='$storage_smb_desc' 
                UNION ALL 
                SELECT 1 FROM storage_nfs WHERE storage_nfs_desc='$storage_smb_desc'
                UNION ALL
                SELECT 1 FROM storage_ssh WHERE storage_ssh_desc='$storage_smb_desc'
                ";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $exist = $sth->fetchColumn();

        if ($exist) {
            $ret[] = ['field' => 'smb-name-exists'];
            echo json_encode($ret, JSON_UNESCAPED_UNICODE);
            exit;
        }

        array_push($audit, _("Adicionado armazenamento SMB:"));
        if (!empty($storage_smb_pass)) {
            $storage_smb_pass = "(select encrypt('" . $storage_smb_pass . "'::bytea, decode(digital_sign, 'hex'), crypt_pass) as teste from security)";
            $field_pass = ',storage_smb_pass';
            $value_pass = ',' . $storage_smb_pass;
        }

        $sql = "INSERT INTO storage_smb (storage_smb_desc, storage_smb_addr, storage_smb_user, storage_smb_dir, box_id $field_pass) VALUES ('$storage_smb_desc', '$storage_smb_addr', '$storage_smb_user', '$storage_smb_dir', '$box_id' $value_pass)";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $dbh->lastInsertId('storage_smb_storage_smb_id_seq');
        $storage_smb_name = selectOne("select host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from obj_addr where addr_id = $storage_smb_addr ", $dbh);
    }

    $box_desc = selectOne("select description from box where box_id = $box_id ", $dbh);

    array_push($audit, _("Servidor: ") . $box_desc['description']);
    array_push($audit, _("Armazenamento: ") . $storage_smb_desc);
    array_push($audit, _("Endereço IP: ") . filter_var($storage_smb_name['host'], FILTER_SANITIZE_STRING));
    array_push($audit, _("Ponto de montagem:  ") . filter_var($storage_smb_dir, FILTER_SANITIZE_STRING));
    logAudit("system", "edit", $audit);

    $apply = new LibApply("storage", __FUNCTION__);
    $apply->exec();

    echo "1";
}

function saveObjNfs()
{
    $box_id = 1;
    $ret = array();
    // $storage_nfs_id = $_REQUEST['nfs-id'];
    // $storage_nfs_desc = $_REQUEST['nfs-name'];
    // $storage_nfs_extra = $_REQUEST['nfs-extra'];

    $storage_nfs_id = validFormRequest($ret, "int", 'nfs-id', true);
    $storage_nfs_desc = validFormRequest($ret, "char", 'nfs-name');
    $storage_nfs_extra = validFormRequest($ret, "char", 'nfs-extra', true);
    $storage_nfs_dir = validFormRequest($ret, "char", 'nfs-dir');
    $nfs_reading = validFormRequest($ret, "int", 'nfs-reading');
    $nfs_writing = validFormRequest($ret, "int", 'nfs-writing');
    $nfs_prot = validFormRequest($ret, "char", 'nfs-prot');
    $nfs_mod = validFormRequest($ret, "char", 'nfs-mod');
    $nfs_locking = validFormRequest($ret, "char", 'nfs-locking', true);
    $storage_nfs_addr = validFormRequest($ret, 'int', 'nfs-src');
    $nfs_port = validFormRequest($ret, 'int', 'nfs-port');

    // Retorna o campo com erro
    if (sizeof($ret) > 0) {
        echo json_encode($ret, JSON_UNESCAPED_UNICODE);
        exit;
    }

    $storage_nfs_dir = quotemeta($_REQUEST['nfs-dir']);

    // if (!validForm("char", $storage_nfs_desc, 0)) {
    //     exit;
    // }

    $nfs_reading = str_replace(' ', '', $_REQUEST['nfs-reading']);
    $nfs_writing = str_replace(' ', '', $_REQUEST['nfs-writing']);
    $nfs_prot = str_replace(' ', '', $_REQUEST['nfs-prot']);
    $nfs_bloco = str_replace(' ', '', $_REQUEST['nfs-bloco']);
    $nfs_locking = str_replace(' ', '', $_REQUEST['nfs-locking']);
    $nfs_mod = str_replace(' ', '', $_REQUEST['nfs-mod']);
    $nfs_posix = str_replace(' ', '', $_REQUEST['nfs-posix']);


    $storage_extra = "";

    if (!empty($nfs_mod))
        $storage_extra .= "$nfs_mod,";
    if (!empty($nfs_locking))
        $storage_extra .= "nolock,";
    if (!empty($nfs_posix))
        $storage_extra .= "posix,";
    if (!empty($nfs_prot) && $nfs_prot != "false")
        $storage_extra .= "$nfs_prot,";
    if (!empty($nfs_reading))
        $storage_extra .= "rsize=$nfs_reading,";
    if (!empty($nfs_writing))
        $storage_extra .= "wsize=$nfs_writing,";
    if (!empty($nfs_bloco) && $nfs_bloco)
        $storage_extra .= "bsize=$nfs_bloco,";
    if (!empty($nfs_port))
        $storage_extra .= "port=$nfs_port";
    if (!empty($storage_nfs_extra) && $storage_nfs_extra)
        $storage_extra .= ",extra=$storage_nfs_extra";

    $audit = [];

    $dbh = connectDB();

    if ($storage_nfs_id) {
        array_push($audit, _("Alterado armazenamento NFS:"));
        $sql = "UPDATE storage_nfs SET storage_nfs_desc = '$storage_nfs_desc', storage_nfs_addr = '$storage_nfs_addr', storage_nfs_dir = '$storage_nfs_dir', storage_nfs_extra = '$storage_extra' where storage_nfs_id = '" . $storage_nfs_id . "'";
        $dbh->query($sql);
        $storage_nfs_name = selectOne("select host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from obj_addr where addr_id = $storage_nfs_addr ", $dbh);
    } else {
        $sql = "SELECT 1 FROM storage_smb WHERE storage_smb_desc='$storage_nfs_desc' 
        UNION ALL 
        SELECT 1 FROM storage_nfs WHERE storage_nfs_desc='$storage_nfs_desc'
        UNION ALL
        SELECT 1 FROM storage_ssh WHERE storage_ssh_desc='$storage_nfs_desc'
        ";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $exist = $sth->fetchColumn();

        if ($exist) {
            $ret[] = ['field' => 'nfs-name-exists'];
            echo json_encode($ret, JSON_UNESCAPED_UNICODE);
            exit;
        }

        array_push($audit, _("Adicionado armazenamento NFS:"));
        $sql = "INSERT INTO storage_nfs (storage_nfs_desc, storage_nfs_addr, storage_nfs_dir, storage_nfs_extra, box_id) VALUES ('$storage_nfs_desc', '$storage_nfs_addr', '$storage_nfs_dir', '$storage_extra', '$box_id')";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $dbh->lastInsertId('storage_nfs_storage_nfs_id_seq');
        $storage_nfs_name = selectOne("select host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from obj_addr_host where addr_id = $storage_nfs_addr ", $dbh);
    }

    $box_desc = selectOne("select description from box where box_id = $box_id ", $dbh);
    array_push($audit, _("Servidor: ") . filter_var($box_desc['description'], FILTER_SANITIZE_STRING));
    array_push($audit, _("Descrição: ") . filter_var($storage_nfs_desc, FILTER_SANITIZE_STRING));
    array_push($audit, _("Endereço IP: ") . filter_var($storage_nfs_name['host'], FILTER_SANITIZE_STRING));
    array_push($audit, _("Ponto de montagem:  ") . filter_var($storage_nfs_dir, FILTER_SANITIZE_STRING));
    array_push($audit, _("Opções extras: ") . filter_var($storage_extra, FILTER_SANITIZE_STRING));
    logAudit("system", "edit", $audit);

    $apply = new LibApply("storage", __FUNCTION__);
    $apply->exec();

    echo "1";
}

//QUOTA
function quotastorage()
{
    require_once("/opt/omne/admin/lib/lib-ssh.php");

    $dir = $_REQUEST['dir'];
    $type = $_REQUEST['type'];
    $box_id = $_REQUEST['box_id'];

    if ($type == 'disco')
        $type = 'usb';

    if ($type === "nfs") {
        $sql = "SELECT
                storage_nfs_id as id,
                storage_nfs_addr,
                storage_nfs_desc as name,
                storage_nfs_extra,
                obj_addr.data->>'obj_addr-name' as addr_name,
                obj_addr.data->>'obj_addr-description' as addr_description,
                storage_nfs_dir,
                host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet)
            FROM storage_nfs
            LEFT JOIN obj_addr on obj_addr.id = storage_nfs_addr
            where storage_nfs_id = '" . $_REQUEST['dir'] . "'";
        $dbh = connectDB();
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $obj = $sth->fetchAll(PDO::FETCH_ASSOC);
        $obj = isset($obj[0]) ? $obj[0] : $obj;
        $nfs_server = $obj["host"];
        $nfsExtra=explode("port=",$obj["storage_nfs_extra"]);
        $port = "";
            if(isset($nfsExtra[1])){
            $port=$nfsExtra[1];
        }
        $telnet_cmd = "echo exit | timeout --signal=9 2 telnet $nfs_server $port 2>&1";
        $command = execCmd($telnet_cmd);
        $cmd = $command[1];
        if ((strpos($cmd,"Connected") === false) || (!file_exists("/storage/nfs/".escapeshellcmd($dir)))) {
            echo _("Armazenamento Indisponível");
            exit ;
        }
    }

    $c = "/usr/bin/df -h /storage/" . escapeshellcmd($type) . "/" . escapeshellcmd($dir);
    $command = execCmd($c, $box_id);
    $cmd = $command[1];

    $str = preg_replace('/\s+/', ';', $cmd);

    $total = explode(';', $str)[1];
    $use = explode(';', $str)[2];
    $value = explode(';', $str)[4];

    $val = intval($value);

    $ret['total'] = $total;
    $ret['use'] = $use;
    $ret['val'] = $val;


    // $ret['total'] = 150;
    // $ret['use'] = 48;
    // $ret['val'] = 77;
    
    if ($ret['total'] == '0' && ($ret['use'] == '0' || $ret['use'] == false) && $ret['val'] == '0') {
        echo _("Armazenamento Indisponível");
        return;
    }

    if (empty($value)) {
        echo _("Armazenamento Indisponível");
        return;
    }

    echo json_encode($ret, JSON_UNESCAPED_UNICODE);
    exit;
}

//RELOAD USB
function reloadUsb()
{
    $box_id = $_REQUEST['box_id'];

    require_once("/opt/omne/admin/lib/lib-ssh.php");

    $cmd = "omne-apply-storage";
    execCmd($cmd, $box_id);
    return 1;
}

function saveSSH()
{

    $sshID = $_REQUEST['ssh-id'];
    $sshDesc = $_REQUEST['ssh-desc'];
    $sshIP = $_REQUEST['ssh-ip'];
    $sshPort = $_REQUEST['ssh-port'];
    $sshUsername = $_REQUEST['ssh-user'];
    $sshDir = $_REQUEST['ssh-dir'];
    $sshComp = $_REQUEST['ssh-comp'];
    $error = array();
    
    if (!validForm('int', $sshID, 1))
        exit;

    if (!validForm('char', $sshDesc)) {
        $err = ['field' => 'ssh-desc'];
        array_push($error, $err);
    }
    if (!validForm('int', $sshIP)) {
        $err = ['field' => 'ssh-ip'];
        array_push($error, $err);
    }
    if (!validForm('int', $sshPort)) {
        $err = ['field' => 'ssh-port'];
        array_push($error, $err);
    }
    if (!validForm('char', $sshUsername)) {
        $err = ['field' => 'ssh-user'];
        array_push($error, $err);
    }
    
    if (!validForm('char', $sshDir)) {
        $err = ['field' => 'ssh-dir'];
        array_push($error, $err);
    }
    if (!validForm('char', $sshComp, 1)) {
        exit;
    }
    
    if ($error) {
        echo json_encode($error, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    if (empty($sshComp))
        $sshComp = 'f';

    $audit = array();
    $dbh = connectDB();
    
    if ($sshID) {
        $sql = "update storage_ssh set storage_ssh_desc = '$sshDesc', storage_ssh_addr = $sshIP, storage_ssh_dir = '$sshDir', storage_ssh_user = '$sshUsername', storage_ssh_port = '$sshPort', storage_ssh_comp = '$sshComp' where storage_ssh_id = $sshID";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        array_push($audit, _("Alterado armazenamento SSH:"));
    } else {
        $sql = "SELECT 1 FROM storage_smb WHERE storage_smb_desc='$sshDesc' 
        UNION ALL 
        SELECT 1 FROM storage_nfs WHERE storage_nfs_desc='$sshDesc'
        UNION ALL
        SELECT 1 FROM storage_ssh WHERE storage_ssh_desc='$sshDesc'
        ";
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $exist = $sth->fetchColumn();

        if ($exist) {
            $ret[] = ['field' => 'ssh-desc-exists'];
            echo json_encode($ret, JSON_UNESCAPED_UNICODE);
            exit;
        }

        $sql = "insert into storage_ssh (storage_ssh_desc, storage_ssh_addr, storage_ssh_dir, storage_ssh_user, storage_ssh_port, storage_ssh_comp) values ";
        $sql .= "('$sshDesc', '$sshIP', '$sshDir', '$sshUsername', '$sshPort', '$sshComp') returning storage_ssh_id";
        
        $sth = $dbh->prepare($sql);
        $sth->execute();
        $sshID = $sth->fetchColumn();
        array_push($audit, _("Adicionado armazenamento SSH:"));
    }

    $ip = selectOne("select host(((obj_addr.data->'obj_addr-ip_mask')->>0)::inet) from obj_addr where addr_id = $sshIP ", $dbh);
    $port = selectOne("select name from obj_ports where port_id = $sshPort ", $dbh);

    array_push($audit, _("Descrição: ") . filter_var($sshDesc, FILTER_SANITIZE_STRING));
    array_push($audit, _("Endereço IP: ") . filter_var($ip['host'], FILTER_SANITIZE_STRING));
    array_push($audit, _("Porta: ") . filter_var($port['name'], FILTER_SANITIZE_STRING));
    array_push($audit, _("Ponto de montagem:  ") . filter_var($sshDir, FILTER_SANITIZE_STRING));

    if ($sshComp == 1)
        array_push($audit, _("Opções extras: Compressão"));

    logAudit("system", "edit", $audit);

    $apply = new LibApply("storages", __FUNCTION__, $sshID);
    $apply->exec();

    echo "1";
}

function getStorageSSH()
{
    $id = filter_var($_REQUEST['id'], FILTER_SANITIZE_NUMBER_INT);

    if (empty($id)) {
        exit;
    }

    define("DIR", "/opt/omne/admin/files/keys/$id.key.pub");

    $dbh = connectDB();
    $sql = "select 
                storage_ssh.*, 
                obj_addr.data ->> 'obj_addr-name' as ip_label, 
                jsonb_array_elements(obj_services.data->'obj_services-ports')->>'obj_services-port_dst_end' as port
            FROM 
                storage_ssh
            LEFT JOIN obj_addr on storage_ssh.storage_ssh_addr = obj_addr.id 
            LEFT JOIN obj_services on storage_ssh.storage_ssh_port = obj_services.id 
            wHERE
                storage_ssh_id = '$id' 
                limit 1";

    $sth = $dbh->prepare($sql);
    $sth->execute();
    $arr1 = $sth->fetchAll(PDO::FETCH_ASSOC);

    $arr1[0]['rsa_key'] = file_get_contents(DIR);

    echo json_encode($arr1);
}
